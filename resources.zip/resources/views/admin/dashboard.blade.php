<div class="page-content-wrapper">
	<div class="page-content">
		<div class="row">
			<div class="col-md-12">
				<div class="portlet light">
					
					<div class="portlet-body">
						<div class="table-container">
							<table class="table table-striped table-bordered table-hover" id="datatable_ajax">
							<tr><th>No. Of Doctors</th><td>({{$list['doctors']}})</td></tr>
							<tr><th>No. Of Hospitals</th><td>({{$list['hospitals']}})</td></tr>
							<tr><th>No. Of Services</th><td>({{$list['services']}})</td></tr>
							<tr><th>No. Of Appointments</th><td>({{$list['appointments']}})</td></tr>
								
							</table>
						</div>
					</div>
				</div>
				<!-- End: life time stats -->
			</div>
		</div>
		<!-- END PAGE CONTENT-->
	</div>
</div>
